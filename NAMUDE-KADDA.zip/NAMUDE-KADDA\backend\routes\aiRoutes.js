// ==========================================================
// aiRoutes.js - Kadda AI endpoints routing
// ==========================================================

const express = require('express');
const router = express.Router();
const aiController = require('../controllers/aiController');

// POST /api/ai - Ask Kadda for product recommendations
router.post('/', aiController.askKadda);

module.exports = router;
