// ==========================================================
// aiController.js - Smart recommendation system for Kadda AI
// ==========================================================

const { pool } = require('../db');

// Handle shopping query from user
// Endpoint: POST /api/ai
// Body: { question: "Find a birthday gift under ₹1000" }
exports.askKadda = async (req, res) => {
    try {
        const { question } = req.body;

        if (!question || question.trim() === '') {
            return res.status(400).json({
                error: 'Please ask Kadda a question or describe what you need.'
            });
        }

        const lowerQ = question.toLowerCase();

        // 1. Extract budget/price limit if mentioned (e.g. "under 1000", "below ₹2500", "under 500")
        let maxPrice = null;
        const priceMatch = lowerQ.match(/(?:under|below|less than|within|upto|up to|budget of)?\s*(?:₹|rs\.?|inr)?\s*(\d{2,6})/i);
        if (priceMatch && priceMatch[1]) {
            maxPrice = parseFloat(priceMatch[1].replace(/,/g, ''));
        }

        // 2. Identify potential category hints
        let detectedCategory = null;
        if (/gift|present|birthday|hamper|anniversary/i.test(lowerQ)) {
            detectedCategory = 'Gifts';
        } else if (/fashion|sneaker|shoes|shoe|wear|cloth|dress/i.test(lowerQ)) {
            detectedCategory = 'Fashion';
        } else if (/electronic|earbud|headphone|watch|gadget|smart/i.test(lowerQ)) {
            detectedCategory = 'Electronics';
        } else if (/food|bakery|bread|eat|veggie|vegetable|snack|grocery/i.test(lowerQ)) {
            detectedCategory = 'Food';
        } else if (/beauty|skin|face|serum|glow|cosmetic/i.test(lowerQ)) {
            detectedCategory = 'Beauty';
        } else if (/home|living|mug|cup|decor|kitchen/i.test(lowerQ)) {
            detectedCategory = 'Home & Living';
        }

        // 3. Extract keywords (remove common stop words)
        const stopWords = new Set([
            'find', 'me', 'a', 'an', 'the', 'for', 'under', 'below', 'less', 'than',
            'in', 'to', 'of', 'and', 'or', 'show', 'i', 'need', 'want', 'looking',
            'please', 'can', 'you', 'recommend', 'give', 'best', 'good', 'cheap', 'budget'
        ]);

        const words = lowerQ
            .replace(/[^a-z0-9\s]/g, ' ')
            .split(/\s+/)
            .filter(w => w.length > 2 && !stopWords.has(w) && isNaN(w));

        // 4. Build dynamic SQL query based on extracted criteria
        let sql = 'SELECT * FROM products WHERE 1=1';
        const params = [];

        if (maxPrice !== null && !isNaN(maxPrice)) {
            sql += ' AND price <= ?';
            params.push(maxPrice);
        }

        if (detectedCategory) {
            sql += ' AND (category = ?';
            params.push(detectedCategory);

            if (words.length > 0) {
                const keywordClauses = words.map(() => '(name LIKE ? OR description LIKE ?)');
                sql += ' OR (' + keywordClauses.join(' OR ') + '))';
                words.forEach(word => {
                    params.push(`%${word}%`, `%${word}%`);
                });
            } else {
                sql += ')';
            }
        } else if (words.length > 0) {
            const keywordClauses = words.map(() => '(name LIKE ? OR description LIKE ? OR category LIKE ?)');
            sql += ' AND (' + keywordClauses.join(' OR ') + ')';
            words.forEach(word => {
                params.push(`%${word}%`, `%${word}%`, `%${word}%`);
            });
        }

        sql += ' ORDER BY rating DESC, price ASC LIMIT 4';

        let [matches] = await pool.query(sql, params);

        // Fallback: If no direct matches, find top rated products within budget or generally top rated
        if (matches.length === 0) {
            let fallbackSql = 'SELECT * FROM products';
            const fallbackParams = [];

            if (maxPrice !== null && !isNaN(maxPrice)) {
                fallbackSql += ' WHERE price <= ?';
                fallbackParams.push(maxPrice);
            }

            fallbackSql += ' ORDER BY rating DESC LIMIT 3';
            const [fallbackRows] = await pool.query(fallbackSql, fallbackParams);
            matches = fallbackRows;
        }

        // 5. Generate conversational AI message
        let responseMessage = '';
        if (matches.length > 0) {
            const productNames = matches.map(p => `${p.name} (₹${p.price})`).join(', ');
            if (maxPrice) {
                responseMessage = `✨ Kadda AI found great options under ₹${maxPrice}: ${productNames}.`;
            } else {
                responseMessage = `✨ Kadda AI recommends: ${productNames}.`;
            }
        } else {
            responseMessage = `✨ Kadda AI couldn't find an exact match, but you can explore our trending deals above!`;
        }

        res.status(200).json({
            message: responseMessage,
            question,
            maxPrice,
            detectedCategory,
            products: matches
        });
    } catch (error) {
        console.error('Error in Kadda AI recommendation:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
