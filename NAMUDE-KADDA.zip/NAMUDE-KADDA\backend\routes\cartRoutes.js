// ==========================================================
// cartRoutes.js - Cart endpoints routing
// ==========================================================

const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');

// GET /api/cart/:user_id - Get user's cart
router.get('/:user_id', cartController.getUserCart);

// POST /api/cart - Add or update cart item
router.post('/', cartController.addToCart);

// DELETE /api/cart/:id - Remove item from cart
router.delete('/:id', cartController.removeFromCart);

module.exports = router;
