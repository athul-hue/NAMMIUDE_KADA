// ==========================================================
// orderRoutes.js - Order endpoints routing
// ==========================================================

const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// POST /api/orders - Place order from cart
router.post('/', orderController.createOrder);

// GET /api/orders/:user_id - Get user order history
router.get('/:user_id', orderController.getUserOrders);

module.exports = router;
