// ==========================================================
// storeController.js - Handles local stores operations
// ==========================================================

const { pool } = require('../db');

// 1. Get all stores
// Endpoint: GET /api/stores
exports.getAllStores = async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM stores ORDER BY id ASC');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching stores:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 2. Get store by ID
// Endpoint: GET /api/stores/:id
exports.getStoreById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await pool.query('SELECT * FROM stores WHERE id = ?', [id]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Store not found' });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error('Error fetching store by ID:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
