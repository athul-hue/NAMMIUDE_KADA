// ==========================================================
// userRoutes.js - User authentication & profile routes
// ==========================================================

const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// POST /api/users/register - Register new account
router.post('/register', userController.registerUser);

// POST /api/users/login - User login
router.post('/login', userController.loginUser);

// GET /api/users/:id - Get user profile
router.get('/:id', userController.getUserById);

module.exports = router;
