// ==========================================================
// userController.js - Handles user authentication & profile
// ==========================================================

const bcrypt = require('bcryptjs');
const { pool } = require('../db');

// 1. Register a new user
// Endpoint: POST /api/users/register
// Body: { name, email, password }
exports.registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Validation
        if (!name || !email || !password) {
            return res.status(400).json({ error: 'Name, email, and password are required' });
        }

        const normalizedEmail = email.trim().toLowerCase();

        // Check if user already exists
        const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
        if (existing.length > 0) {
            return res.status(409).json({ error: 'Email is already registered' });
        }

        // Hash the password with bcrypt (10 salt rounds)
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Insert new user into MySQL
        const insertSql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
        const [result] = await pool.query(insertSql, [name.trim(), normalizedEmail, hashedPassword]);

        // Return user info WITHOUT password
        res.status(201).json({
            message: 'User registered successfully',
            user: {
                id: result.insertId,
                name: name.trim(),
                email: normalizedEmail
            }
        });
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 2. User login
// Endpoint: POST /api/users/login
// Body: { email, password }
exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validation
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const normalizedEmail = email.trim().toLowerCase();

        // Find user by email
        const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [normalizedEmail]);
        if (rows.length === 0) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const user = rows[0];

        // Compare provided password with hashed password in database
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Return user info WITHOUT password
        res.status(200).json({
            message: 'Login successful',
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            }
        });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 3. Get user details by ID
// Endpoint: GET /api/users/:id
exports.getUserById = async (req, res) => {
    try {
        const { id } = req.params;

        // Never select password column
        const [rows] = await pool.query('SELECT id, name, email, created_at FROM users WHERE id = ?', [id]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error('Error fetching user by ID:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
