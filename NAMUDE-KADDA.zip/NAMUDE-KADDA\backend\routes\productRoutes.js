// ==========================================================
// productRoutes.js - Product endpoints routing
// ==========================================================

const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// Define search and category BEFORE :id to avoid route collision
// GET /api/products/search?q=...
router.get('/search', productController.searchProducts);

// GET /api/products/category/:category
router.get('/category/:category', productController.getProductsByCategory);

// GET /api/products - Get all products
router.get('/', productController.getAllProducts);

// GET /api/products/:id - Get single product
router.get('/:id', productController.getProductById);

// POST /api/products - Create product
router.post('/', productController.createProduct);

// PUT /api/products/:id - Update product
router.put('/:id', productController.updateProduct);

// DELETE /api/products/:id - Delete product
router.delete('/:id', productController.deleteProduct);

module.exports = router;
