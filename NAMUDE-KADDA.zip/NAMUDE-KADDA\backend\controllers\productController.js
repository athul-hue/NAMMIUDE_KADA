// ==========================================================
// productController.js - Handles product-related database operations
// ==========================================================

const { pool } = require('../db');

// 1. Get all products from MySQL
exports.getAllProducts = async (req, res) => {
    try {
        // Query to select all products ordered by newest first
        const [rows] = await pool.query('SELECT * FROM products ORDER BY id ASC');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 2. Search products by name, category, seller, or description
// Endpoint: GET /api/products/search?q=query
exports.searchProducts = async (req, res) => {
    try {
        const query = req.query.q;

        // Validation: Empty search term
        if (!query || query.trim() === '') {
            return res.status(400).json({ error: 'Search term is required' });
        }

        const searchTerm = `%${query.trim()}%`;
        const sql = `
            SELECT * FROM products 
            WHERE name LIKE ? 
               OR category LIKE ? 
               OR seller LIKE ? 
               OR description LIKE ?
            ORDER BY id ASC
        `;

        const [rows] = await pool.query(sql, [searchTerm, searchTerm, searchTerm, searchTerm]);
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error searching products:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 3. Filter products by category
// Endpoint: GET /api/products/category/:category
exports.getProductsByCategory = async (req, res) => {
    try {
        const { category } = req.params;

        const sql = 'SELECT * FROM products WHERE LOWER(category) = LOWER(?) ORDER BY id ASC';
        const [rows] = await pool.query(sql, [category]);

        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching category products:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 4. Get a single product by ID
// Endpoint: GET /api/products/:id
exports.getProductById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error('Error fetching product by ID:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 5. Add a new product (POST /api/products)
exports.createProduct = async (req, res) => {
    try {
        const {
            name,
            price,
            original_price,
            category,
            seller,
            rating = 4.5,
            review_count = 0,
            discount = '',
            description = '',
            emoji = '🛍️',
            bg_color = '#ede9fe'
        } = req.body;

        // Basic validation
        if (!name || !price || !category || !seller) {
            return res.status(400).json({ error: 'Name, price, category, and seller are required fields' });
        }

        const sql = `
            INSERT INTO products 
            (name, price, original_price, category, seller, rating, review_count, discount, description, emoji, bg_color)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await pool.query(sql, [
            name,
            price,
            original_price || price,
            category,
            seller,
            rating,
            review_count,
            discount,
            description,
            emoji,
            bg_color
        ]);

        res.status(201).json({
            message: 'Product created successfully',
            productId: result.insertId
        });
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 6. Update an existing product (PUT /api/products/:id)
exports.updateProduct = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name,
            price,
            original_price,
            category,
            seller,
            rating,
            review_count,
            discount,
            description,
            emoji,
            bg_color
        } = req.body;

        // Check if product exists first
        const [existing] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
        if (existing.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        const current = existing[0];
        const sql = `
            UPDATE products 
            SET name = ?, price = ?, original_price = ?, category = ?, seller = ?,
                rating = ?, review_count = ?, discount = ?, description = ?, emoji = ?, bg_color = ?
            WHERE id = ?
        `;

        await pool.query(sql, [
            name !== undefined ? name : current.name,
            price !== undefined ? price : current.price,
            original_price !== undefined ? original_price : current.original_price,
            category !== undefined ? category : current.category,
            seller !== undefined ? seller : current.seller,
            rating !== undefined ? rating : current.rating,
            review_count !== undefined ? review_count : current.review_count,
            discount !== undefined ? discount : current.discount,
            description !== undefined ? description : current.description,
            emoji !== undefined ? emoji : current.emoji,
            bg_color !== undefined ? bg_color : current.bg_color,
            id
        ]);

        res.status(200).json({ message: 'Product updated successfully' });
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 7. Delete a product (DELETE /api/products/:id)
exports.deleteProduct = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
