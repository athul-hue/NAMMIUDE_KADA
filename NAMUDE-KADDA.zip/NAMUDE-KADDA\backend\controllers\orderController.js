// ==========================================================
// orderController.js - Handles checkout and order history
// ==========================================================

const { pool } = require('../db');

// 1. Create a new order from user's cart
// Endpoint: POST /api/orders
// Body: { user_id }
exports.createOrder = async (req, res) => {
    // Acquire a dedicated connection for a MySQL transaction
    const connection = await pool.getConnection();

    try {
        const { user_id = 1 } = req.body;

        // Start transaction
        await connection.beginTransaction();

        // 1. Read the user's cart items
        const cartSql = `
            SELECT c.id AS cart_id, c.product_id, c.quantity, p.name, p.price 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = ?
        `;
        const [cartItems] = await connection.query(cartSql, [user_id]);

        if (cartItems.length === 0) {
            await connection.rollback();
            connection.release();
            return res.status(400).json({ error: 'Cart is empty. Add products before checking out.' });
        }

        // 2. Calculate the order total
        const totalAmount = cartItems.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * item.quantity);
        }, 0);

        // 3. Create the order record
        const orderSql = 'INSERT INTO orders (user_id, total_amount, status) VALUES (?, ?, ?)';
        const [orderResult] = await connection.query(orderSql, [user_id, totalAmount.toFixed(2), 'Completed']);
        const orderId = orderResult.insertId;

        // 4. Create the order_items records
        const itemSql = 'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)';
        for (const item of cartItems) {
            await connection.query(itemSql, [orderId, item.product_id, item.quantity, item.price]);
        }

        // 5. Clear the user's cart
        await connection.query('DELETE FROM cart WHERE user_id = ?', [user_id]);

        // Commit the transaction to save all changes
        await connection.commit();
        connection.release();

        res.status(201).json({
            message: 'Order placed successfully',
            order: {
                id: orderId,
                user_id,
                total_amount: totalAmount.toFixed(2),
                items_count: cartItems.length,
                status: 'Completed'
            }
        });
    } catch (error) {
        await connection.rollback();
        connection.release();
        console.error('Error creating order:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 2. Get order history for a user
// Endpoint: GET /api/orders/:user_id
exports.getUserOrders = async (req, res) => {
    try {
        const { user_id } = req.params;

        const orderSql = `
            SELECT id, user_id, total_amount, status, created_at 
            FROM orders 
            WHERE user_id = ? 
            ORDER BY id DESC
        `;
        const [orders] = await pool.query(orderSql, [user_id]);

        // Fetch items for each order
        for (const order of orders) {
            const itemsSql = `
                oi.id, oi.product_id, oi.quantity, oi.price, p.name, p.emoji
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ?
            `;
            const [items] = await pool.query('SELECT oi.id, oi.product_id, oi.quantity, oi.price, p.name, p.emoji FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?', [order.id]);
            order.items = items;
        }

        res.status(200).json(orders);
    } catch (error) {
        console.error('Error fetching user orders:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
