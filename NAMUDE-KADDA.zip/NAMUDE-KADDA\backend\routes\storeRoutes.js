// ==========================================================
// storeRoutes.js - Store endpoints routing
// ==========================================================

const express = require('express');
const router = express.Router();
const storeController = require('../controllers/storeController');

// GET /api/stores - List all stores
router.get('/', storeController.getAllStores);

// GET /api/stores/:id - Single store detail
router.get('/:id', storeController.getStoreById);

module.exports = router;
