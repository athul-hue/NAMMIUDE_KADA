// ==========================================================
// cartController.js - Handles cart operations
// ==========================================================

const { pool } = require('../db');

// 1. Get user cart items
// Endpoint: GET /api/cart/:user_id
exports.getUserCart = async (req, res) => {
    try {
        const { user_id } = req.params;

        // Join cart with products table to get full product details
        const sql = `
            SELECT 
                c.id AS cart_id,
                c.user_id,
                c.product_id,
                c.quantity,
                p.name,
                p.price,
                p.original_price,
                p.emoji,
                p.bg_color,
                p.seller,
                p.category
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.user_id = ?
            ORDER BY c.id DESC
        `;

        const [rows] = await pool.query(sql, [user_id]);
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching cart items:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 2. Add product to cart
// Endpoint: POST /api/cart
// Body: { user_id, product_id, quantity }
exports.addToCart = async (req, res) => {
    try {
        const { user_id = 1, product_id, quantity = 1 } = req.body;

        if (!product_id) {
            return res.status(400).json({ error: 'Product ID is required' });
        }

        const qty = parseInt(quantity, 10) || 1;

        // Check if this product is already in the user's cart
        const checkSql = 'SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?';
        const [existing] = await pool.query(checkSql, [user_id, product_id]);

        if (existing.length > 0) {
            // Product already in cart: update quantity
            const newQty = existing[0].quantity + qty;
            const updateSql = 'UPDATE cart SET quantity = ? WHERE id = ?';
            await pool.query(updateSql, [newQty, existing[0].id]);

            return res.status(200).json({
                message: 'Cart item quantity updated',
                cart_id: existing[0].id,
                quantity: newQty
            });
        } else {
            // New item: insert into cart table
            const insertSql = 'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)';
            const [result] = await pool.query(insertSql, [user_id, product_id, qty]);

            return res.status(201).json({
                message: 'Product added to cart',
                cart_id: result.insertId,
                quantity: qty
            });
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};

// 3. Remove item from cart
// Endpoint: DELETE /api/cart/:id
exports.removeFromCart = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await pool.query('DELETE FROM cart WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Cart item not found' });
        }

        res.status(200).json({ message: 'Item removed from cart' });
    } catch (error) {
        console.error('Error removing from cart:', error);
        res.status(500).json({ error: 'Database connection failed' });
    }
};
